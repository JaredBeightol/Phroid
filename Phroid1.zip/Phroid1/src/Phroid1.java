/*
 * Jared Beightol
 * 9/10/18
 * Purpose: In version 1, the goal is for Phroid to learn how to have a simple conversation by storing a humans exact response to outputs.
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Phroid1 {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		String input1;
		String input2;
		String output1;
//		int conversationCounter = 0;
		boolean conversation = true;
		
		
		
		while (conversation) {
//			//Prints out how many exchanges there has been
//			conversationCounter = conversationCounter + 1;
//			System.out.println(conversationCounter);
			//takes user input
			input1 = userInput.nextLine();
			
			
			
			//Try catch, try to find the document that is named after the input, if there isn't one, 
			//output the last input, and serialize a document named after the input, and the response
			try {
				//DESERIALIZE
			    FileInputStream f_in = new FileInputStream(input1 + ".data");
			    ObjectInputStream obj_in = new ObjectInputStream (f_in);
			    output1 = (String)obj_in.readObject();
			    System.out.println(output1);
			} catch (Exception e) {
				
				System.out.println(input1);
				
				input2 = userInput.nextLine();
				
				try {
					//SERIALIZE
					FileOutputStream f_out = new FileOutputStream(input1 + ".data");
				    ObjectOutputStream obj_out = new ObjectOutputStream (f_out);
				    obj_out.writeObject (input2);
				}catch (Exception IOException) {
			    	System.out.println("--ERROR WRITING--");
			    }   
			}	
		}
		//Closes userInput Scanner
		userInput.close();	
	}
}
